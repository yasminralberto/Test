import Cocoa

var num = 1

print(num)
